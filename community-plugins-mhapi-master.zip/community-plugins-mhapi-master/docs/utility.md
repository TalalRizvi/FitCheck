# Utility

This namespace wraps various calls which are convenient but not necessarily MH-specific.

## getTypeAsString(content)

## getValueAsString(content, newLinesIfComplex=False)

## isPySideAvailable()

## isPyQtAvailable()

## isPython3()

## getCompatibleUrlFetcher()

## getLogChannel(name, defaultLevel=2, mirrorToMHLog=False)

## resetDebugWriter(channelName = "unsorted")

## debugWrite(content, channelName = "unsorted", location = "genericLocation")

