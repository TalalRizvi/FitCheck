# Exports

This namespace wraps all calls that are related to producing file output.

## getExportFormats()

## getExporterByClassname(className)

## fileentry(ext)

## getOBJExporter()

## getFBXExporter()

## getDAEExporter()

## getMHX2Exporter()

## exportAsOBJ(outputFilename, useExportsDir=True)

Export the current toon as wavefront obj.

## exportAsFBX(outputFilename, useExportsDir=True)

Export the current toon as wavefront obj.

## exportAsDAE(outputFilename, useExportsDir=True)

Export the current toon as wavefront obj.

## exportAsMHX2(outputFilename, useExportsDir=True)

Export the current toon as wavefront obj.

