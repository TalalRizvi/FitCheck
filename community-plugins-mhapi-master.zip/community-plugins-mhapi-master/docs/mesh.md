# Mesh

This namespace wraps call which works directly on mesh vertices, edges and faces.

## getVertexCoordinates()

Return an array with the current position of vertices

## getAllProxies(includeBodyProxy=False)

## getCurrentProxy()

## getCurrentHair()

## getCurrentEyes()

## getCurrentEyebrows()

## getCurrentEyelashes()

## getCurrentTeeth()

## getCurrentTongue()

## getClothes()

## getFaceGroupFaceIndexes()

