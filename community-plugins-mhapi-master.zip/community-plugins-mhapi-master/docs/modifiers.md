# Modifiers

This namespace wraps calls concerning modifiers and targets.

## applyModifier(modifierName, power, assumeThreading = False)

## applyTarget(targetName,power, assumeThreading = False)

## getAppliedTargets()

## setAge(age)

## setWeight(weight)

## setMuscle(muscle)

## setHeight(height)

## setGender(gender)

## getAvailableModifierNames()

## applySymmetryLeft()

## applySymmetryRight()

