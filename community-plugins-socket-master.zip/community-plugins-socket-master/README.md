# community-plugins-socket
Socket server for makehuman
