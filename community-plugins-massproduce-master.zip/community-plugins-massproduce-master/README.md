# Mass Produce

Plugin for randomizing large sets of humans

This plugin is in heavy development and not yet fit for public use. 

# Dependencies

You will need an updated MHAPI to run this. The one bundled with alpha2 will not suffice. 
